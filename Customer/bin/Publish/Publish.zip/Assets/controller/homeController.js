﻿(function (window, $) {
    window.home = {
        ui: {

        },
        init: function () {
            home.regisControl();
        },
        regisControl: function () {
           
        }
    }
})(window, jQuery);

$(document).ready(function () {
    home.init();
});